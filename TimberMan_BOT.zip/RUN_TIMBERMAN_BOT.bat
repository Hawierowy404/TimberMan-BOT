@echo off
cd /d "%~dp0"
start "TimberMan BOT By Hawierowy" pyw TimberMan_BOT_By_Hawierowy.py
