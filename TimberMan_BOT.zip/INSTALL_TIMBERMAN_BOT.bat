@echo off
title TimberMan BOT By Hawierowy - First Installation
color 0B
echo ============================================================
echo          TimberMan BOT By Hawierowy - Installer
echo ============================================================
echo.
where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python was not found.
  echo Download Python 3 from https://www.python.org/downloads/
  echo During installation, enable: Add Python to PATH
  pause
  exit /b 1
)
echo [1/3] Updating the Python package installer...
py -m pip install --upgrade pip
if errorlevel 1 goto failed
echo.
echo [2/3] Installing required libraries...
py -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 goto failed
echo.
echo [3/3] Verifying the application...
py -m py_compile "%~dp0TimberMan_BOT_By_Hawierowy.py"
if errorlevel 1 goto failed
echo.
echo ============================================================
echo Installation completed successfully.
echo Run the bot using: RUN_TIMBERMAN_BOT.bat
echo ============================================================
pause
exit /b 0
:failed
echo.
echo Installation failed. Read FIRST_INSTALL_GUIDE_EN.txt
pause
exit /b 1
