import threading
import time
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import messagebox

import pyautogui
from pynput.keyboard import Key, Listener


BASE_DIR = Path(__file__).resolve().parent
SCREENSHOT_DIR = BASE_DIR / "screenshots"
SENSOR_REGION = (840, 610, 240, 24)
ACTIVITY_REGION = (900, 430, 120, 260)
LOOP_DELAY = 0.045
SCREENSHOT_INTERVAL = 1.0


class TimberBot:
    def __init__(self):
        self.running = threading.Event()
        self.exit_event = threading.Event()
        self.last_pressed_left = True
        self.last_saved = 0.0
        self.static_frames = 0
        self.reference = None
        self.locked_chops = 0
        self.sync_ms = 45
        self.ui_callback = None
        SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def color_difference(first, second):
        return sum(abs(a - b) for a, b in zip(first, second))

    def check_branch(self, image):
        patch_width = 14
        changed_left = 0
        changed_right = 0
        for y in range(image.height):
            for x in range(patch_width):
                if self.color_difference(image.getpixel((x, y)),
                                         self.reference.getpixel((x, y))) > 60:
                    changed_left += 1
                rx = image.width - 1 - x
                if self.color_difference(image.getpixel((rx, y)),
                                         self.reference.getpixel((rx, y))) > 60:
                    changed_right += 1
        if max(changed_left, changed_right) < 24:
            return "None"
        return "Left" if changed_left > changed_right else "Right"

    def save_diagnostic(self, image, side):
        now = time.monotonic()
        if now - self.last_saved < SCREENSHOT_INTERVAL:
            return
        self.last_saved = now
        stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S_%f")[:-3]
        image.save(SCREENSHOT_DIR / f"sensor_{stamp}_{side}.png")
        self.notify_ui("screenshot", side)

    def notify_ui(self, event, value=None):
        if self.ui_callback:
            self.ui_callback(event, value)

    @staticmethod
    def images_differ(first, second):
        return first.tobytes() != second.tobytes()

    def clear_screenshots_after_loss(self):
        removed = 0
        for image_path in SCREENSHOT_DIR.glob("*.png"):
            try:
                image_path.unlink()
                removed += 1
            except OSError:
                pass
        print(f"PRZEGRANA: usunięto {removed} zrzutów. Bot zatrzymany.")

    def bot_loop(self):
        while not self.exit_event.is_set():
            if not self.running.is_set():
                time.sleep(0.03)
                continue

            activity_before = pyautogui.screenshot(region=ACTIVITY_REGION)
            image = pyautogui.screenshot(region=SENSOR_REGION)
            side = self.check_branch(image)
            self.save_diagnostic(image, side)

            if self.locked_chops > 0:
                self.locked_chops -= 1
            elif side == "Left" and self.last_pressed_left:
                self.last_pressed_left = False
                self.locked_chops = 1
            elif side == "Right" and not self.last_pressed_left:
                self.last_pressed_left = True
                self.locked_chops = 1

            if self.last_pressed_left:
                pyautogui.press("left")
                self.notify_ui("side", "left")
            else:
                pyautogui.press("right")
                self.notify_ui("side", "right")

            time.sleep(max(0.001, min(0.100, self.sync_ms / 1000.0)))
            activity_after = pyautogui.screenshot(region=ACTIVITY_REGION)
            if self.images_differ(activity_before, activity_after):
                self.static_frames = 0
            else:
                self.static_frames += 1
            if self.static_frames >= 4:
                self.running.clear()
                self.clear_screenshots_after_loss()
                self.static_frames = 0
                self.notify_ui("loss")

    def on_key(self, key):
        if key == Key.f8:
            self.static_frames = 0
            self.locked_chops = 0
            self.reference = pyautogui.screenshot(region=SENSOR_REGION)
            self.running.set()
            print("BOT: START — wzorzec pobrany, synchronizacja 45 ms")
            self.notify_ui("running", True)
        elif key == Key.f9:
            self.running.clear()
            print("BOT: STOP")
            self.notify_ui("running", False)
        elif key == Key.esc:
            self.running.clear()
            self.exit_event.set()
            return False

    def run(self):
        print("Timberman Bot 12321")
        print("F8 = start | F9 = stop | Esc = wyjście")
        print(f"Zrzuty: {SCREENSHOT_DIR}")
        worker = threading.Thread(target=self.bot_loop, daemon=True)
        worker.start()
        with Listener(on_press=self.on_key) as listener:
            listener.join()


class TimberBotHUD:
    TRANSLATIONS = {
        "pl": {"language": "🇵🇱 Polski", "subtitle": "Precyzyjna automatyzacja Timbermana",
               "status": "STATUS", "ready": "Gotowy", "running": "BOT DZIAŁA", "stopped": "Zatrzymany",
               "lost": "Wykryto przegraną — zrzuty usunięte", "start": "▶  START  (F8)", "stop": "■  STOP  (F9)",
               "side": "AKTUALNY RUCH", "left": "← LEWO", "right": "PRAWO →", "shots": "ZRZUTY DIAGNOSTYCZNE",
               "speed": "SYNCHRONIZACJA", "hint": "F8 uruchamia  •  F9 zatrzymuje  •  Esc zamyka",
               "folder": "OTWÓRZ FOLDER ZRZUTÓW"},
        "en": {"language": "🇬🇧 English", "subtitle": "Precision Timberman automation",
               "status": "STATUS", "ready": "Ready", "running": "BOT RUNNING", "stopped": "Stopped",
               "lost": "Loss detected — screenshots cleared", "start": "▶  START  (F8)", "stop": "■  STOP  (F9)",
               "side": "CURRENT MOVE", "left": "← LEFT", "right": "RIGHT →", "shots": "DIAGNOSTIC SCREENSHOTS",
               "speed": "SYNC TIMING", "hint": "F8 starts  •  F9 stops  •  Esc exits", "folder": "OPEN SCREENSHOT FOLDER"},
        "ru": {"language": "🇷🇺 Русский", "subtitle": "Точная автоматизация Timberman",
               "status": "СТАТУС", "ready": "Готов", "running": "БОТ РАБОТАЕТ", "stopped": "Остановлен",
               "lost": "Поражение — снимки удалены", "start": "▶  СТАРТ  (F8)", "stop": "■  СТОП  (F9)",
               "side": "ТЕКУЩИЙ ХОД", "left": "← ВЛЕВО", "right": "ВПРАВО →", "shots": "СНИМКИ",
               "speed": "СИНХРОНИЗАЦИЯ", "hint": "F8 старт  •  F9 стоп  •  Esc выход", "folder": "ОТКРЫТЬ ПАПКУ"},
        "ja": {"language": "🇯🇵 日本語", "subtitle": "Timberman 高精度オートメーション",
               "status": "ステータス", "ready": "準備完了", "running": "ボット実行中", "stopped": "停止",
               "lost": "ゲームオーバー — 画像を削除しました", "start": "▶  開始  (F8)", "stop": "■  停止  (F9)",
               "side": "現在の動き", "left": "← 左", "right": "右 →", "shots": "診断画像",
               "speed": "同期", "hint": "F8 開始  •  F9 停止  •  Esc 終了", "folder": "画像フォルダーを開く"},
        "ko": {"language": "🇰🇷 한국어", "subtitle": "정밀 Timberman 자동화",
               "status": "상태", "ready": "준비됨", "running": "봇 실행 중", "stopped": "중지됨",
               "lost": "게임 오버 — 스크린샷 삭제됨", "start": "▶  시작  (F8)", "stop": "■  중지  (F9)",
               "side": "현재 이동", "left": "← 왼쪽", "right": "오른쪽 →", "shots": "진단 스크린샷",
               "speed": "동기화", "hint": "F8 시작  •  F9 중지  •  Esc 종료", "folder": "스크린샷 폴더 열기"},
        "zh": {"language": "🇨🇳 中文", "subtitle": "精准 Timberman 自动化",
               "status": "状态", "ready": "准备就绪", "running": "机器人运行中", "stopped": "已停止",
               "lost": "游戏结束 — 截图已删除", "start": "▶  开始  (F8)", "stop": "■  停止  (F9)",
               "side": "当前移动", "left": "← 左", "right": "右 →", "shots": "诊断截图",
               "speed": "同步", "hint": "F8 开始  •  F9 停止  •  Esc 退出", "folder": "打开截图文件夹"},
        "de": {"language": "🇩🇪 Deutsch", "subtitle": "Präzise Timberman-Automatisierung",
               "status": "STATUS", "ready": "Bereit", "running": "BOT LÄUFT", "stopped": "Gestoppt",
               "lost": "Verloren — Screenshots gelöscht", "start": "▶  START  (F8)", "stop": "■  STOPP  (F9)",
               "side": "AKTUELLER ZUG", "left": "← LINKS", "right": "RECHTS →", "shots": "DIAGNOSEBILDER",
               "speed": "SYNCHRONISATION", "hint": "F8 Start  •  F9 Stopp  •  Esc Ende", "folder": "BILDERORDNER ÖFFNEN"},
        "es": {"language": "🇪🇸 Español", "subtitle": "Automatización precisa de Timberman",
               "status": "ESTADO", "ready": "Listo", "running": "BOT ACTIVO", "stopped": "Detenido",
               "lost": "Derrota — capturas eliminadas", "start": "▶  INICIAR  (F8)", "stop": "■  PARAR  (F9)",
               "side": "MOVIMIENTO ACTUAL", "left": "← IZQUIERDA", "right": "DERECHA →", "shots": "CAPTURAS",
               "speed": "SINCRONIZACIÓN", "hint": "F8 inicia  •  F9 para  •  Esc sale", "folder": "ABRIR CARPETA"},
        "fr": {"language": "🇫🇷 Français", "subtitle": "Automatisation précise de Timberman",
               "status": "STATUT", "ready": "Prêt", "running": "BOT ACTIF", "stopped": "Arrêté",
               "lost": "Défaite — captures supprimées", "start": "▶  DÉMARRER  (F8)", "stop": "■  ARRÊTER  (F9)",
               "side": "MOUVEMENT ACTUEL", "left": "← GAUCHE", "right": "DROITE →", "shots": "CAPTURES",
               "speed": "SYNCHRONISATION", "hint": "F8 démarre  •  F9 arrête  •  Esc quitte", "folder": "OUVRIR LE DOSSIER"},
        "uk": {"language": "🇺🇦 Українська", "subtitle": "Точна автоматизація Timberman",
               "status": "СТАН", "ready": "Готово", "running": "БОТ ПРАЦЮЄ", "stopped": "Зупинено",
               "lost": "Програш — знімки видалено", "start": "▶  СТАРТ  (F8)", "stop": "■  СТОП  (F9)",
               "side": "ПОТОЧНИЙ РУХ", "left": "← ЛІВОРУЧ", "right": "ПРАВОРУЧ →", "shots": "ЗНІМКИ",
               "speed": "СИНХРОНІЗАЦІЯ", "hint": "F8 старт  •  F9 стоп  •  Esc вихід", "folder": "ВІДКРИТИ ПАПКУ"},
    }

    def __init__(self, root, bot):
        self.root, self.bot = root, bot
        self.language = "pl"
        self.state_key = "ready"
        self.side_key = "left"
        self.shot_count = 0
        self.sync_var = tk.IntVar(value=45)
        self.events = []
        self.events_lock = threading.Lock()
        bot.ui_callback = self.receive_event
        self.build()
        self.apply_language()
        threading.Thread(target=bot.run, daemon=True).start()
        root.after(80, self.poll_events)

    def build(self):
        self.root.title("TimberMan BOT By Hawierowy")
        self.root.geometry("780x720")
        self.root.resizable(False, False)
        self.root.configure(bg="#070d18")
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        accent = tk.Frame(self.root, bg="#22d3ee", height=3)
        accent.pack(fill="x")
        top = tk.Frame(self.root, bg="#070d18", padx=30, pady=24)
        top.pack(fill="x")
        logo = tk.Frame(top, bg="#0e7490", width=48, height=48, highlightbackground="#22d3ee", highlightthickness=1)
        logo.pack(side="left", padx=(0, 14))
        logo.pack_propagate(False)
        tk.Label(logo, text="⚡", bg="#0e7490", fg="white", font=("Segoe UI Emoji", 21, "bold")).pack(expand=True)
        title_box = tk.Frame(top, bg="#070d18")
        title_box.pack(side="left")
        title_line = tk.Frame(title_box, bg="#070d18")
        title_line.pack(anchor="w")
        tk.Label(title_line, text="TIMBERMAN", bg="#070d18", fg="#f8fafc", font=("Segoe UI", 25, "bold")).pack(side="left")
        tk.Label(title_line, text=" BOT", bg="#070d18", fg="#22d3ee", font=("Segoe UI", 25, "bold")).pack(side="left")
        tk.Label(title_box, text="BY HAWIEROWY  •  VISION CONTROL SYSTEM", bg="#070d18", fg="#64748b",
                 font=("Segoe UI", 8, "bold")).pack(anchor="w", pady=(2, 0))
        self.language_button = tk.Menubutton(top, bg="#17243a", fg="white", activebackground="#253b59",
                                             relief="flat", font=("Segoe UI Emoji", 10, "bold"), padx=12, pady=7)
        self.language_button.pack(side="right")
        menu = tk.Menu(self.language_button, tearoff=False, bg="#111c2e", fg="white", activebackground="#0ea5e9",
                       font=("Segoe UI Emoji", 10))
        for code, values in self.TRANSLATIONS.items():
            menu.add_command(label=values["language"], command=lambda c=code: self.set_language(c))
        self.language_button.configure(menu=menu)

        body = tk.Frame(self.root, bg="#070d18", padx=30)
        body.pack(fill="both", expand=True)
        self.subtitle = tk.Label(body, bg="#070d18", fg="#8293aa", font=("Segoe UI", 10))
        self.subtitle.pack(anchor="w", pady=(0, 16))
        status = tk.Frame(body, bg="#101a2b", padx=22, pady=18, highlightbackground="#1e334d", highlightthickness=1)
        status.pack(fill="x")
        self.status_caption = tk.Label(status, bg="#101a2b", fg="#8293aa", font=("Segoe UI", 9, "bold"))
        self.status_caption.pack(anchor="w")
        self.status_value = tk.Label(status, bg="#101a2b", fg="#38bdf8", font=("Segoe UI", 18, "bold"))
        self.status_value.pack(anchor="w", pady=(3, 0))
        self.status_dot = tk.Canvas(status, width=18, height=18, bg="#101a2b", highlightthickness=0)
        self.status_dot.place(relx=1.0, x=-18, y=10, anchor="ne")
        self.dot = self.status_dot.create_oval(3, 3, 15, 15, fill="#64748b", outline="")

        metrics = tk.Frame(body, bg="#070d18")
        metrics.pack(fill="x", pady=14)
        self.side_card, self.side_caption, self.side_value = self.metric_card(metrics)
        self.side_card.pack(side="left", fill="both", expand=True, padx=(0, 7))
        self.shot_card, self.shot_caption, self.shot_value = self.metric_card(metrics)
        self.shot_card.pack(side="left", fill="both", expand=True, padx=7)
        self.speed_card, self.speed_caption, self.speed_value = self.metric_card(metrics)
        self.speed_card.pack(side="left", fill="both", expand=True, padx=(7, 0))
        self.speed_value.configure(text="45 ms")

        sync_card = tk.Frame(body, bg="#101a2b", padx=20, pady=15,
                             highlightbackground="#1e334d", highlightthickness=1)
        sync_card.pack(fill="x", pady=(0, 14))
        sync_head = tk.Frame(sync_card, bg="#101a2b")
        sync_head.pack(fill="x")
        self.sync_title = tk.Label(sync_head, text="SYNC CONTROL", bg="#101a2b", fg="#cbd5e1",
                                   font=("Segoe UI", 10, "bold"))
        self.sync_title.pack(side="left")
        self.sync_live = tk.Label(sync_head, text="45 ms", bg="#083344", fg="#67e8f9",
                                  padx=12, pady=4, font=("Consolas", 11, "bold"))
        self.sync_live.pack(side="right")
        slider_row = tk.Frame(sync_card, bg="#101a2b")
        slider_row.pack(fill="x", pady=(10, 4))
        tk.Label(slider_row, text="1", bg="#101a2b", fg="#64748b", font=("Segoe UI", 8)).pack(side="left")
        self.sync_scale = tk.Scale(slider_row, from_=1, to=100, orient="horizontal", variable=self.sync_var,
                                   command=self.change_sync, showvalue=False, resolution=1, bg="#101a2b",
                                   fg="white", troughcolor="#1e334d", activebackground="#22d3ee",
                                   highlightthickness=0, bd=0, sliderrelief="flat", sliderlength=18)
        self.sync_scale.pack(side="left", fill="x", expand=True, padx=10)
        tk.Label(slider_row, text="100", bg="#101a2b", fg="#64748b", font=("Segoe UI", 8)).pack(side="right")
        self.best_sync = tk.Label(sync_card, text="★  BEST VALUE: 45 ms", bg="#101a2b", fg="#facc15",
                                  font=("Segoe UI", 9, "bold"))
        self.best_sync.pack(anchor="w")

        actions = tk.Frame(body, bg="#070d18")
        actions.pack(fill="x")
        self.start_button = tk.Button(actions, command=self.start, bg="#22c55e", fg="#052e16", activebackground="#4ade80",
                                      relief="flat", pady=13, font=("Segoe UI", 11, "bold"))
        self.start_button.pack(side="left", fill="x", expand=True, padx=(0, 7))
        self.stop_button = tk.Button(actions, command=self.stop, bg="#ef4444", fg="white", activebackground="#f87171",
                                     relief="flat", pady=13, font=("Segoe UI", 11, "bold"))
        self.stop_button.pack(side="left", fill="x", expand=True, padx=(7, 0))
        self.folder_button = tk.Button(body, command=self.open_folder, bg="#17243a", fg="#cbd5e1", activebackground="#253b59",
                                       relief="flat", pady=10, font=("Segoe UI", 9, "bold"))
        self.folder_button.pack(fill="x", pady=(14, 0))
        self.hint = tk.Label(body, bg="#070d18", fg="#52647c", font=("Segoe UI", 9))
        self.hint.pack(pady=18)

    @staticmethod
    def metric_card(parent):
        card = tk.Frame(parent, bg="#101a2b", padx=16, pady=14,
                        highlightbackground="#1e334d", highlightthickness=1)
        caption = tk.Label(card, bg="#101a2b", fg="#8293aa", font=("Segoe UI", 8, "bold"))
        caption.pack(anchor="w")
        value = tk.Label(card, bg="#101a2b", fg="#f8fafc", font=("Segoe UI", 13, "bold"))
        value.pack(anchor="w", pady=(5, 0))
        return card, caption, value

    def set_language(self, code):
        self.language = code
        self.apply_language()

    def change_sync(self, value):
        milliseconds = int(float(value))
        self.bot.sync_ms = milliseconds
        self.sync_live.configure(text=f"{milliseconds} ms")
        self.speed_value.configure(text=f"{milliseconds} ms")

    def apply_language(self):
        t = self.TRANSLATIONS[self.language]
        self.language_button.configure(text=t["language"] + "  ▾")
        self.subtitle.configure(text=t["subtitle"])
        self.status_caption.configure(text=t["status"])
        self.status_value.configure(text=t[self.state_key])
        self.side_caption.configure(text=t["side"])
        self.side_value.configure(text=t[self.side_key])
        self.shot_caption.configure(text=t["shots"])
        self.shot_value.configure(text=str(self.shot_count))
        self.speed_caption.configure(text=t["speed"])
        self.start_button.configure(text=t["start"])
        self.stop_button.configure(text=t["stop"])
        self.folder_button.configure(text=t["folder"])
        self.hint.configure(text=t["hint"])
        sync_text = {
            "pl": ("STEROWANIE SYNCHRONIZACJĄ", "★  NAJLEPSZA WARTOŚĆ: 45 ms"),
            "en": ("SYNC CONTROL", "★  BEST VALUE: 45 ms"),
            "ru": ("УПРАВЛЕНИЕ СИНХРОНИЗАЦИЕЙ", "★  ЛУЧШЕЕ ЗНАЧЕНИЕ: 45 мс"),
            "ja": ("同期コントロール", "★  推奨値: 45 ms"),
            "ko": ("동기화 제어", "★  권장 값: 45 ms"),
            "zh": ("同步控制", "★  最佳值: 45 ms"),
            "de": ("SYNC-STEUERUNG", "★  BESTER WERT: 45 ms"),
            "es": ("CONTROL DE SINCRONIZACIÓN", "★  MEJOR VALOR: 45 ms"),
            "fr": ("CONTRÔLE DE SYNCHRONISATION", "★  MEILLEURE VALEUR : 45 ms"),
            "uk": ("КЕРУВАННЯ СИНХРОНІЗАЦІЄЮ", "★  НАЙКРАЩЕ ЗНАЧЕННЯ: 45 мс"),
        }[self.language]
        self.sync_title.configure(text=sync_text[0])
        self.best_sync.configure(text=sync_text[1])

    def receive_event(self, event, value=None):
        with self.events_lock:
            self.events.append((event, value))

    def poll_events(self):
        with self.events_lock:
            events, self.events = self.events, []
        for event, value in events:
            if event == "running":
                self.state_key = "running" if value else "stopped"
                self.status_dot.itemconfigure(self.dot, fill="#22c55e" if value else "#64748b")
            elif event == "loss":
                self.state_key = "lost"
                self.shot_count = 0
                self.status_dot.itemconfigure(self.dot, fill="#ef4444")
            elif event == "side":
                self.side_key = value
            elif event == "screenshot":
                self.shot_count += 1
        self.apply_language()
        self.root.after(80, self.poll_events)

    def start(self):
        self.bot.on_key(Key.f8)

    def stop(self):
        self.bot.on_key(Key.f9)

    @staticmethod
    def open_folder():
        import os
        os.startfile(SCREENSHOT_DIR)

    def close(self):
        self.bot.running.clear()
        self.bot.exit_event.set()
        self.root.destroy()


if __name__ == "__main__":
    pyautogui.PAUSE = 0
    app_root = tk.Tk()
    TimberBotHUD(app_root, TimberBot())
    app_root.mainloop()
